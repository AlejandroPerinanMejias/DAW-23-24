function cambiarFondo() {
    let color = document.getElementById("color").value;
    document.body.style.backgroundColor = color;
}