let mensaje = "Hola mundo! \nQue facil es incluir 'comillas simples' y \"comillas dobles\"";
alert(mensaje);