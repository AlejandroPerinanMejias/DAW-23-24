function tipo() {
    var valor = document.getElementById("valor").value;
    console.log(typeof valor);
}
